function irParaAdotar() { //quando o botão for acionado, manda o usuário para outra tela//
    document.location.href = 'petcia_telaadotarg.html'
}

function irParaInicial() {  //quando o botão for acionado, manda o usuário para outra tela//
    document.location.href = 'petcia_telainicial.html'
}

function doar() {
    let modal = document.getElementById('modal');
    let fundoescuro = document.getElementById('fundoescuro');

    fundoescuro.style.display = 'block'
    modal.style.display = 'block'; 
    
}

function fecharmodal(){
    let modal = document.getElementById('modal');
    let fundoescuro = document.getElementById('fundoescuro');

    fundoescuro.style.display = 'none'
    modal.style.display = 'none'
}

function abriradocao() {
    let carrinhoAdocao = document.getElementById('carrinhoAdocao');

    carrinhoAdocao.style.display = 'block'; 
    
}

function fecharadote(){
    let carrinhoAdocao = document.getElementById('carrinhoAdocao');

    carrinhoAdocao.style.display = 'none'
}

function irParaAdotarcao() { //quando o botão for acionado, manda o usuário para outra tela//
    document.location.href = 'petcia_telaadotarc.html'
}

function irParaAdotarcoelho() { //quando o botão for acionado, manda o usuário para outra tela//
    document.location.href = 'petcia_telaadotarcoe.html'
}

function irParaAdotarpassaro() { //quando o botão for acionado, manda o usuário para outra tela//
    document.location.href = 'petcia_telaadotarpassaro.html'

}

function irParaDescriçãoCoe1() { //quando o botão for acionado, manda o usuário para outra tela//
    document.location.href = 'Descrição_Animalcoe1.html'
    
}

function irParaDescriçãoCoe2() { //quando o botão for acionado, manda o usuário para outra tela//
    document.location.href = 'Descrição_Animalcoe2.html'
    
}

function irParaDescriçãoCoe3() { //quando o botão for acionado, manda o usuário para outra tela//
    document.location.href = 'Descrição_Animalcoe3.html'
    
}

function irParaDescriçãoCoe4() { //quando o botão for acionado, manda o usuário para outra tela//
    document.location.href = 'Descrição_Animalcoe4.html'
    
}

function irParaDescriçãoCoe5() { //quando o botão for acionado, manda o usuário para outra tela//
    document.location.href = 'Descrição_Animalcoe5.html'
    
}

function irParaDescriçãoCoe6() { //quando o botão for acionado, manda o usuário para outra tela//
    document.location.href = 'Descrição_Animalcoe6.html'
    
}

function irParaDescriçãoCoe7() { //quando o botão for acionado, manda o usuário para outra tela//
    document.location.href = 'Descrição_Animalcoe7.html'
    
}

function irParaDescriçãoCoe8() { //quando o botão for acionado, manda o usuário para outra tela//
    document.location.href = 'Descrição_Animalcoe8.html'
    
}

function irParaDescriçãoCoe9() { //quando o botão for acionado, manda o usuário para outra tela//
    document.location.href = 'Descrição_Animalcoe9.html'
    
}

function irParaDescriçãoCoe10() { //quando o botão for acionado, manda o usuário para outra tela//
    document.location.href = 'Descrição_Animalcoe10.html'
    
}

function irParaDescriçãog1() { //quando o botão for acionado, manda o usuário para outra tela//
    document.location.href = 'Descrição_Animalg1.html'
    
}

function irParaDescriçãog2() { //quando o botão for acionado, manda o usuário para outra tela//
    document.location.href = 'Descrição_Animalg2.html'
    
}
function irParaDescriçãog3() { //quando o botão for acionado, manda o usuário para outra tela//
    document.location.href = 'Descrição_Animalg3.html'
    
}

function irParaDescriçãog4() { //quando o botão for acionado, manda o usuário para outra tela//
    document.location.href = 'Descrição_Animalg4.html'
    
}

function irParaDescriçãog5() { //quando o botão for acionado, manda o usuário para outra tela//
    document.location.href = 'Descrição_Animalg5.html'
    
}

function irParaDescriçãog6() { //quando o botão for acionado, manda o usuário para outra tela//
    document.location.href = 'Descrição_Animalg6.html'
    
}

function irParaDescriçãog7() { //quando o botão for acionado, manda o usuário para outra tela//
    document.location.href = 'Descrição_Animalg7.html'
    
}

function irParaDescriçãog8() { //quando o botão for acionado, manda o usuário para outra tela//
    document.location.href = 'Descrição_Animalg8.html'
    
}

function irParaDescriçãog9() { //quando o botão for acionado, manda o usuário para outra tela//
    document.location.href = 'Descrição_Animalg9.html'
    
}

function irParaDescriçãog10() { //quando o botão for acionado, manda o usuário para outra tela//
    document.location.href = 'Descrição_Animalg10.html'
    
}

function irParaDescriçãoCao1() { //quando o botão for acionado, manda o usuário para outra tela//
    document.location.href = 'Descrição_Animalc1.html'
    
}


function irParaDescriçãoCao2() { //quando o botão for acionado, manda o usuário para outra tela//
    document.location.href = 'Descrição_Animalc2.html'
    
}

function irParaDescriçãoCao3() { //quando o botão for acionado, manda o usuário para outra tela//
    document.location.href = 'Descrição_Animalc3.html'
    
}

function irParaDescriçãoCao4() { //quando o botão for acionado, manda o usuário para outra tela//
    document.location.href = 'Descrição_Animalc4.html'
    
}

function irParaDescriçãoCao5() { //quando o botão for acionado, manda o usuário para outra tela//
    document.location.href = 'Descrição_Animalc5.html'
    
}

function irParaDescriçãoCao6() { //quando o botão for acionado, manda o usuário para outra tela//
    document.location.href = 'Descrição_Animalc6.html'
    
}

function irParaDescriçãoCao7() { //quando o botão for acionado, manda o usuário para outra tela//
    document.location.href = 'Descrição_Animalc7.html'
    
}

function irParaDescriçãoCao8() { //quando o botão for acionado, manda o usuário para outra tela//
    document.location.href = 'Descrição_Animalc8.html'
    
}

function irParaDescriçãoCao9() { //quando o botão for acionado, manda o usuário para outra tela//
    document.location.href = 'Descrição_Animalc9.html'
    
}

function irParaDescriçãoCao10() { //quando o botão for acionado, manda o usuário para outra tela//
    document.location.href = 'Descrição_Animalc10.html'
    
}

function irParaDescriçãop1(){
    document.location.href = 'Descrição_Animalp1.html'
}

function irParaDescriçãop2(){
    document.location.href = 'Descrição_Animalp2.html'
}

function irParaDescriçãop3(){
    document.location.href = 'Descrição_Animalp3.html'
}

function irParaDescriçãop4(){
    document.location.href = 'Descrição_Animalp4.html'
}

function irParaDescriçãop5(){
    document.location.href = 'Descrição_Animalp5.html'
}

function irParaDescriçãop6(){
    document.location.href = 'Descrição_Animalp6.html'
}

function irParaDescriçãop7(){
    document.location.href = 'Descrição_Animalp7.html'
}

function irParaDescriçãop8(){
    document.location.href = 'Descrição_Animalp8.html'
}

function irParaDescriçãop9(){
    document.location.href = 'Descrição_Animalp9.html'
}

function irParaDescriçãop10(){
    document.location.href = 'Descrição_Animalp10.html'
}

function cadastrodoanimal() { //quando o botão for assionado, manda o usuário para outra tela//
    document.location.href = 'Cadastro_Animal.html'
}

function sair(){
    document.location.href = 'petcia_login.html'
}

function descricaoAnimalCad(){
    document.location.href = 'Descrição_AnimalCadastrado.html'
    
}



function exibirAnimais() {
    const animais = JSON.parse(localStorage.getItem('animal')) || [];
        const listaAnimais = document.getElementById('listaAnimais2');
        listaAnimais.innerHTML = '';
        
        //o negócio da url é uma constante que servirá para determinar a página com as condicionais
        const url = window.location.href;

        // Determina se a página atual é para cães ou gatos ou coelhos ou coelhdsdd
        let especie;
        if (url.includes("petcia_telaadotarc.html")) {
            especie = "cao";
        } else if (url.includes("petcia_telaadotarg.html")) {
            especie = "gato";
        }
        else if (url.includes("petcia_telaadotarcoe.html")) {
            especie = "coelho";
        }else if (url.includes("petcia_telaadotarpassaro.html")) {
            especie = "passaro";
        }
    
        // Filtra os animais pela espécie e exibe apenas os da espécie atual
        const animaisFiltrados = animais.filter(animal => animal.resposta === especie);
    
        animaisFiltrados.forEach(animal => {
            const div = document.createElement('div');
            // Define as classes conforme a espécie do animal
            if (especie === "cao") {
                div.classList.add('caoadoção')
            }else if (especie === "gato") {
                div.classList.add('gatoadoção')
            }else if (especie === "coelho") {
                div.classList.add('coelhoadoção')
            }else if (especie === "passaro") {
                div.classList.add('passaroadoção')
            }
            


        // Ele tá Criando a imagem
        const img = document.createElement('img');
        img.src = animal.imagem;
        img.classList.add('caes','gatos','coelhos','passaros');  // Aplica a classe que define o estilo das imagens (do tamanho correto)

        // Criando o nome do animal
        const nome = document.createElement('p');
        nome.textContent = animal.nomeAnimal;
        
        
        // Adicionando a imagem e o nome dentro da div
        div.appendChild(img);
        div.appendChild(nome);

        // Adicionando a div à lista de animais cadastrados
        listaAnimais.appendChild(div);
    });
}

exibirAnimais()


